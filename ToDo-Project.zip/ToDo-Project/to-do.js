let todoList = [];
displayItems();
function addButton(){
    let inputElement = document.querySelector('#todo-input');
    let dateElement = document.querySelector('#todo-date');
    let todoItem = inputElement.value;
    let todoDate = dateElement.value;
    todoList.push({item: todoItem,dueDate: todoDate});
    inputElement.value = '';
    dateElement.value = '';
    displayItems();
}
function displayItems(){
    let displayEle = document.querySelector('.todo-containner');
    let newHtml = '';
    for(let i =0;i<todoList.length;i++)
        {
            let {item,dueDate} = todoList[i];
            newHtml += `
                <span>${item}</span>
                <span>${dueDate}</span>
                <button class = 'btn-delete' onClick="todoList.splice(${i},1);
                displayItems();"> Delete</button>
            `;
        }
    displayEle.innerHTML = newHtml;
}